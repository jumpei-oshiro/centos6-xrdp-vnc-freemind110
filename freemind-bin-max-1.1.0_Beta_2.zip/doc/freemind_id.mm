<map version="0.9.0_Beta_8">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node COLOR="#993300" CREATED="1124560950701" ID="ID_1694064349" MODIFIED="1207926619789">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body width="">
    <p align="center">
      FreeMind<br /><small>- perangkat lunak bebas untuk</small><br /><small>pembuatan MindMap -</small>&#160;
    </p>
  </body>
</html></richcontent>
<font BOLD="true" NAME="Dialog" SIZE="18"/>
<node CREATED="1124560950701" ID="ID_278812263" LINK="http://freemind.sourceforge.net" MODIFIED="1207927061884" POSITION="left" TEXT="Situs web FreeMind">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1091417446" MODIFIED="1207927121089" POSITION="left" TEXT="Tabel kunci pintasan">
<node CREATED="1124560950701" ID="ID_163135330" MODIFIED="1208312544662" TEXT="Perintah berkas:&#xa;Peta baru       - Ctrl+N&#xa;Buka peta       - Ctrl+O&#xa;Simpan peta     - Ctrl+S&#xa;Simpan sebagai  - Ctrl+A&#xa;Cetak           - Ctrl+P&#xa;Tutup           - Ctrl+W&#xa;Keluar          - Ctrl+Q&#xa;Peta sblmnya    - Ctrl+LEFT&#xa;Peta berikutnya - Ctrl+RIGHT&#xa;Ekspor berkas ke HTML            - Ctrl+E&#xa;Ekspor cabang ke HTML            - Ctrl+H&#xa;Ekspor cabang ke berkas MM baru  - Alt+A&#xa;Buka berkas pertama dari riwayat - Ctrl+Shift+W&#xa;&#xa;Perintah edit:&#xa;Cari            - Ctrl+F&#xa;Cari berikutnya - Ctrl+G&#xa;Potong          - Ctrl+X&#xa;Salin           - Ctrl+C&#xa;Salin tunggal   - Ctrl+Y&#xa;Tempelkan       - Ctrl+V&#xa;&#xa;Perintah modus:&#xa;Modus MindMap - Alt+1&#xa;Modus jelajah - Alt+2 &#xa;Modus berkas  - Alt+3&#xa;&#xa;Perintah pemformatan node:&#xa;Miringkan                 - Ctrl+I&#xa;Tebalkan                  - Ctrl+B&#xa;Awan                      - Ctrl+Shift+B&#xa;Ubah warna node           - Alt+C&#xa;Campur warna node         - Alt+B&#xa;Ubah warna tangkai node   - Alt+E&#xa;Perbesar font node        - Ctrl+L&#xa;Perkecil font node        - Ctrl+M&#xa;Perbesar font cabang      - Ctrl+Shift+L&#xa;Perkecil font cabang      - Ctrl+Shift+M&#xa;&#xa;Perintah navigasi node:&#xa;Pergi ke akar   - ESCAPE&#xa;Pindah ke atas  - UP&#xa;Pindah ke bawah - DOWN&#xa;Pindah ke kiri  - LEFT&#xa;Pindah ke kanan - RIGHT&#xa;Ikuti taut      - Ctrl+ENTER&#xa;Zum keluar      - Alt+UP&#xa;Zum masuk       - Alt+DOWN&#xa;&#xa;Perintah node baru:&#xa;Tambah node adik  - ENTER&#xa;Tambah node anak  - INSERT&#xa;Tambah node kakak - Shift+ENTER&#xa;&#xa;Perintah edit node:&#xa;Edit node terpilih        - F2&#xa;Edit node panjang         - Alt+ENTER&#xa;Gabungkan node            - Ctrl+J&#xa;Buka-tutup lipatan        - SPACE&#xa;Buka-tutup lipatan anak   - Ctrl+SPACE&#xa;Setel taut lewat pemilih berkas   - Ctrl+Shift+K&#xa;Setel taut lewat kolom teks       - Ctrl+K&#xa;Setel gambar lewat pemilih berkas - Alt+K&#xa;Pindahkan node ke atas    - Ctrl+UP&#xa;Pindahkan node ke bawah   - Ctrl+DOWN&#xa;">
<font NAME="Courier New" SIZE="12"/>
</node>
</node>
<node COLOR="#006633" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_904501221" MODIFIED="1208312560404" POSITION="left" TEXT="Instalasi">
<node COLOR="#006699" CREATED="1124560950701" ID="_Freemind_Link_1911559485" MODIFIED="1208312973308" TEXT="Taut">
<node CREATED="1124560950701" ID="ID_1972294106" LINK="http://java.sun.com/j2se" MODIFIED="1208312579943" TEXT="Unduh Java Runtime Environment (minimal J2RE1.4)">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1612101865" LINK="http://sourceforge.net/project/showfiles.php?project_id=7118" MODIFIED="1208312597618" TEXT="Unduh Aplikasi FreeMind">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_139664576" MODIFIED="1208312738440" TEXT="Untuk instalasi FreeMind di Microsoft Windows, pasang Java dari Sun lalu pasang FreeMind menggunakan program pemasang (installer) yang tersedia."/>
<node CREATED="1124560950701" ID="_Freemind_Link_1380352758" MODIFIED="1208312876759" TEXT="Untuk instalasi FreeMind di Linux, unduh Java Runtime Environment dan aplikasi FreeMind itu sendiri. Pasang Java terlebih dahulu, lalu bongkar (unpack) paket FreeMind. Untuk menjalankan FreeMind, jalankan freemind.sh."/>
<node CREATED="1124560950701" ID="_Freemind_Link_1808511462" MODIFIED="1208312948773" TEXT="Di Microsoft Windows dan Mac OS X, Anda juga dapat langsung mendobel-klik berkas freemind.jar yang berlokasi di map bernama lib untuk memulai FreeMind."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_353522063" MODIFIED="1208313002620" POSITION="left" TEXT="Menjelajahi berkas dalam komputer">
<node CREATED="1124560950701" ID="ID_350447496" MODIFIED="1208313244338" TEXT="Untuk menjelajahi sistem berkas komputer, beralihlah ke modus File lewat perintah Peta &gt; File dari menu."/>
<node CREATED="1124560950701" ID="ID_1896842303" MODIFIED="1208313283114" TEXT="Anda dapat menjelajahi struktur berkas seolah membaca MindMap."/>
<node CREATED="1124560950701" ID="ID_1343540447" MODIFIED="1208773411572" TEXT="Agar suatu map menjadi node yang mengambil posisi tengah, klik kanan pada node tersebut lalu pilih Tengah."/>
<node CREATED="1124560950701" ID="ID_305820556" MODIFIED="1208773450654" TEXT="Untuk melihat, mengedit, atau menjalankan berkas, ikuti tautan node tersebut."/>
<node CREATED="1124560950701" ID="_Freemind_Link_279880616" MODIFIED="1208773660294" TEXT="Modus File saat ini tidak begitu bermanfaat, melainkan hanya untuk menunjukkan bahwa tidak sulit untuk mengumpankan data ke dalam peta dari sumber data lain selain MindMap. Sejauh ini tampaknya orang tidak akan benar-benar menggunakan modus ini."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1530607683" MODIFIED="1208773697151" POSITION="left" TEXT="Menjelajahi MindMap">
<node CREATED="1124560950701" ID="ID_245563788" MODIFIED="1208773837850" TEXT="Untuk menjelajahi MindMap namun tanpa mengeditnya, beralihlah ke modus Browse melalui menu Peta &gt; Browse. Fungsi ini tidak digunakan selain daripada di dalam FreeMind applet.&#xa;"/>
<node CREATED="1124560950701" ID="ID_729697699" MODIFIED="1208773954416" TEXT="Ada alasan teknis mengapa modus Browse terpisah dibutuhkan. Menjelajah (browse) adalah satu-satunya operasi yang dapat dilakukan melalui FreeMind applet, yang dapat ditempelkan dalam laman web Anda. Umumnya, Anda tidak akan menggunakan modus Browse dalam FreeMind.&#xa;"/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1136088046" MODIFIED="1208961883966" POSITION="left" TEXT="Tentang modus">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1713057526" MODIFIED="1208962776570" TEXT="Walaupun FreeMind utamanya adalah alat penyunting MindMap, desainnya memungkinkan pemakaian untuk membaca data dari berbagai sumber. Untuk membuat suatu sumber data tertentu tersedia untuk dilihat di FreeMind, pemrogram harus membuat apa yang disebut modus untuk sumber data tersebut. Salah satu contohnya adalah modus File. Setahu kami belum ada modus lain yang telah diimplementasi. Belum pasti apakah akan ada yang memanfaatkan arsitektur ini, namun hal ini bisa dilakukan bila diinginkan.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_700085988" MODIFIED="1208963696673" TEXT="Contoh lain yang sudah hampir jadi dibuat adalah ada modus Scheme, untuk menyunting program dalam bahasa Scheme. Sekali lagi, manfaatnnya masih belum jelas. Kecuali modus MindMap, modus-modus lain lebih merupakan demonstrasi tentang apa yang mungkin dilakukan dengan program ini, bukan untuk benar-benar digunakan.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1525986009" MODIFIED="1208963727668" POSITION="left" TEXT="Instalasi applet FreeMind di situs web Anda">
<node COLOR="#000000" CREATED="1124560950701" ID="ID_686268443" MODIFIED="1208963801474" TEXT="Anda dapat memasang applet FreeMind di situs web Anda agar orang dapat membaca MindMap Anda.">
<font NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1433718684" LINK="http://sourceforge.net/project/showfiles.php?group_id=7118" MODIFIED="1208963819980" TEXT="Unduh applet, yaitu freemind-browser."/>
<node CREATED="1124560950701" ID="ID_316824945" MODIFIED="1208964470245" TEXT="Paket unduhan berisi freemindbrowser.jar dan freemindbrowser.html. Buat tautan dari laman web Anda ke freemindbrowser.html. Di dalam freemindbrowser.html, ganti jalur (path) dalam berkas tersebut agar menunjuk ke MindMap yang Anda buat."/>
<node CREATED="1124560950701" ID="ID_1135453004" MODIFIED="1208964565172" TEXT="Berkas jar dari applet tersebut harus diletakkan di peladen yang sama dengan MindMap yang dibuka, sebagai syarat keamanan dari Java. Anda harus mengunggah berka jar applet FreeMind dan MindMap Anda ke laman web tersebut."/>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1083756111" MODIFIED="1208964602766" POSITION="left" TEXT="Menggunakan FreeMind applet">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_514864900" MODIFIED="1208965257287" TEXT="Dalam applet FreeMind, Anda hanya dapat menggunakan modus Browse (jelajah), Anda tidak dapat menyunting peta dari jarak jauh. Klik node untuk membuka-tutup lipatan atau membuka tautan. Seret latar belakang untuk memindahkan peta. Untuk mencari dalam peta, gunakan menu konteks node.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1976458022" MODIFIED="1208965297475" POSITION="left" TEXT="Perubahan antarmuka di versi 0.6.5">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="_Freemind_Link_717349033" MODIFIED="1208965557349" STYLE="fork" TEXT="Beberapa setelan papan ketik didefinisikan ulang untuk menyamakan dengan apa yang dianggap setelan bersama atau yang intuitif. Beberapa dari setelan tersebut dimodelkan atas program-program Windows. Beberapa setelan baru misalnya Enter untuk membuat saudara baru di bawah node sekarang, Insert untuk membuat anak baru, F2 untuk mengedit Node - di sini pengaruh Microsoft sangat jelas walaupun tidak ada alasan intuitif mengapa F2 dipakai untuk mengedit node. Namun begitu Anda terbiasa dengan hal tersebut di semua aplikasi yang Anda gunakan, Anda akan menginginkannya juga di FreeMind.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1179893656" MODIFIED="1208965331784" TEXT="Setelan papan ketik dapat diganti melalui menu Alat &gt; Preferensi.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_784043927" MODIFIED="1208773990119" POSITION="left" TEXT="Penghargaan">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_415458128" MODIFIED="1208774001268" TEXT="Penulis">
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1896457660" MODIFIED="1124560950701" TEXT="Joerg Mueller">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:ponders@t-online.de" MODIFIED="1124560950701" TEXT="ponders@t-online.de">
<font NAME="Dialog" SIZE="10"/>
</node>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="University of Freiburg, Germany">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_984984595" LINK="http://mujweb.cz/www/danielpolansky" MODIFIED="1124560950701" TEXT="Daniel Polansky">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_459203293" MODIFIED="1124560950701" TEXT="Petr Novak">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_875814410" MODIFIED="1124560950701" TEXT="Christian Foltin">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#558000" CREATED="1124560950701" LINK="mailto:christian.foltin@gmx.de" MODIFIED="1124560950701" TEXT="christian.foltin@gmx.de">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" ID="_Freemind_Link_1415293905" MODIFIED="1124560950701" TEXT="Dimitri Polivaev">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_816166020" MODIFIED="1208774033132" TEXT="Sumbangan lain">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_1164774797" MODIFIED="1124560950701" TEXT="Andrew Iggleden">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_615905950" MODIFIED="1208966039732" TEXT="Instalasi Windows">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1096673251" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1498630478" MODIFIED="1208966051800" TEXT="Panduan Eclipse">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1024053399" MODIFIED="1124560950701" TEXT="David Butt">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_158863537" MODIFIED="1208966057187" TEXT="Tutorial Flash">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_1572312597" MODIFIED="1124560950701" TEXT="David Low">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_760522438" MODIFIED="1208966069585" TEXT="Membantu">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_360501151" MODIFIED="1208774040521" TEXT="Penerjemahan">
<node COLOR="#996600" CREATED="1208774087264" FOLDED="true" ID="ID_962580873" MODIFIED="1208774118696" STYLE="fork" TEXT="Permata Harahap">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<node COLOR="#999999" CREATED="1208774125193" ID="ID_1424643889" MODIFIED="1208966146215" STYLE="fork" TEXT="terjemahan bahasa Indonesia">
<edge COLOR="#808080" STYLE="bezier" WIDTH="thin"/>
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_807977431" MODIFIED="1124560950701" TEXT="Bob Alexander">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1125551331" MODIFIED="1124560950701" TEXT="Italian translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1853214917" MODIFIED="1124560950701" TEXT="Knud Riish&#xf8;jg&#xe5;rd">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_846744145" MODIFIED="1124560950701" TEXT="Danish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_1676529317" MODIFIED="1124560950701" TEXT="Takeshi Kakeda">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562983644" FOLDED="true" ID="Freemind_Link_1172193026" MODIFIED="1124562984816" TEXT="Kohichi Aoki">
<node COLOR="#999999" CREATED="1124560950701" ID="ID_934842072" MODIFIED="1124560950701" TEXT="Japanese translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="ID_761116196" MODIFIED="1124560950701" TEXT="Alex Dukal">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562998159" FOLDED="true" ID="Freemind_Link_757563697" MODIFIED="1124563008034" TEXT="Hugo Gayosso">
<node COLOR="#999999" CREATED="1124560950701" ID="Freemind_Link_1783275246" MODIFIED="1124560950701" TEXT="Spanish translation">
<edge WIDTH="thin"/>
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="Freemind_Link_929540960" MODIFIED="1124560950701" TEXT="Sylvain Gamel">
<node COLOR="#999999" CREATED="1124560950701" MODIFIED="1124560950701" TEXT="French translation">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561242082" FOLDED="true" ID="Freemind_Link_946171164" MODIFIED="1124561245019" TEXT="Koen Roggemans">
<node COLOR="#999999" CREATED="1124561245957" ID="Freemind_Link_1819881845" MODIFIED="1124561251675" TEXT="Dutch translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561374999" FOLDED="true" ID="Freemind_Link_235962981" MODIFIED="1124561376718" TEXT="Rafal Kraik">
<node COLOR="#999999" CREATED="1124561377702" ID="Freemind_Link_459079511" MODIFIED="1124561382155" TEXT="Polish translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561969717" FOLDED="true" ID="Freemind_Link_653284985" MODIFIED="1124561972920" TEXT="Goliath">
<node COLOR="#999999" CREATED="1124561438294" ID="Freemind_Link_1387213811" MODIFIED="1124561445950" TEXT="Korean translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561753254" FOLDED="true" ID="Freemind_Link_35211963" MODIFIED="1124563712385" TEXT="Martin Srebotnjak (nick: Miles a.k.a. filmsi)">
<node COLOR="#999999" CREATED="1124561491886" ID="Freemind_Link_835144271" MODIFIED="1124561506386" TEXT="Slovenian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561814721" FOLDED="true" ID="Freemind_Link_1008886206" MODIFIED="1124561818580" TEXT="William Chen">
<node COLOR="#999999" CREATED="1124561497308" ID="Freemind_Link_1960552629" MODIFIED="1124561506011" TEXT="Chinese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124561823877" FOLDED="true" ID="Freemind_Link_1650138043" MODIFIED="1124561876907" TEXT="Radek &#x160;varc">
<node COLOR="#999999" CREATED="1124561515761" ID="Freemind_Link_768227373" MODIFIED="1124561519885" TEXT="Czech translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562250475" FOLDED="true" ID="Freemind_Link_901975324" MODIFIED="1124562252007" TEXT="Bal&#xe1;zs M&#xe1;rton">
<node COLOR="#999999" CREATED="1124562252585" ID="Freemind_Link_557911120" MODIFIED="1124562258428" TEXT="Hungarian translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#996600" CREATED="1124562948942" FOLDED="true" ID="Freemind_Link_290351026" MODIFIED="1124562950270" TEXT="Luis Ferreira ">
<node COLOR="#999999" CREATED="1124562956332" ID="Freemind_Link_6081004" MODIFIED="1124562961879" TEXT="Portuguese translation">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124563066204" ID="Freemind_Link_23652566" MODIFIED="1208966247321" TEXT="Daftar penerjemahan ini mungkin belum lengkap. Bila ada yang terlupakan, beritahu kami. Semua orang yang kami ketahui telah menyumbangkan paling sedikit penerjemahan sebagian sudah ada dalam daftar.">
<font NAME="SansSerif" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_487339822" MODIFIED="1208967115239" POSITION="right" TEXT="Tekan Ctrl + F untuk mencari. Tekan Ctrl + G untuk mengulang pencarian terakhir. Agar pencarian dilakukan global, tekan Esc sebelum mencari."/>
<node COLOR="#0033ff" CREATED="1124560950701" ID="ID_1540220959" MODIFIED="1208967142848" POSITION="right" TEXT="Tekan panah kanan untuk membuka lipatan node."/>
<node COLOR="#407000" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1596161299" MODIFIED="1209144350344" POSITION="right" TEXT="Pengantar">
<node CREATED="1124560950701" ID="ID_234585361" MODIFIED="1209144426964" TEXT="FreeMind memungkinkan kita membuat apa yang disebut sebagai MindMap. Meski begitu, banyak orang menggunakannya sebagai alternatif dari buku catatan atau alat pengelola informasi pribadi."/>
<node CREATED="1124560950701" ID="ID_660297789" MODIFIED="1209144496845" TEXT="Informasi disimpan dalam kotak teks, disebut node. Node dihubungkan satu sama lain dengan garis melengkung yang kita sebut tangkai."/>
<node CREATED="1124560950701" ID="ID_1286515401" MODIFIED="1209144542891" TEXT="Dokumentasi ini dibuat untuk FreeMind 0.8.0. Pemetaan kunci pintasan dan lokasi fungsi menu bisa berubah dari satu versi ke versi lainnya."/>
</node>
<node COLOR="#996600" CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_706084071" MODIFIED="1209144562459" POSITION="right" TEXT="Demonstrasi beberapa fitur">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#669900" CREATED="1124560950701" ID="_Freemind_Link_735193624" MODIFIED="1209144584160" TEXT="Tampilan">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_690312221" MODIFIED="1209144600864" TEXT="Node bisa dibuat berbagai warna">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#ff0000" CREATED="1124560950701" ID="ID_1678736213" MODIFIED="1209144605871" TEXT="Merah">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#009900" CREATED="1124560950701" ID="ID_767661247" MODIFIED="1209144610358" TEXT="Hijau">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#0000cc" CREATED="1124560950701" ID="ID_1716843014" MODIFIED="1209144614043" TEXT="Biru">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="_" MODIFIED="1209144652959" TEXT="Node bisa punya berbagai warna latar belakang">
<node CREATED="1124560950701" ID="_Freemind_Link_1358611533" MODIFIED="1209144658287" TEXT="Ini"/>
<node CREATED="1124560950701" ID="_Freemind_Link_1317973766" MODIFIED="1209144661972" TEXT="Itu"/>
</node>
<node CREATED="1124560950701" ID="ID_1132374703" MODIFIED="1209144683773" TEXT="Node bisa dibuat dalam berbagai gaya huruf">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1639593324" MODIFIED="1209144688971" TEXT="Tebal">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1376999225" MODIFIED="1209144693157" TEXT="Miring">
<font ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1864392974" MODIFIED="1209144699045" TEXT="Tebal dan miring">
<font BOLD="true" ITALIC="true" NAME="Dialog" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" ID="ID_834524132" MODIFIED="1209144718984" TEXT="Huruf node bisa dibuat dalam berbagai ukuran">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1791375192" MODIFIED="1209144724832" TEXT="kecil">
<font NAME="SansSerif" SIZE="11"/>
</node>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="normal">
<font NAME="SansSerif" SIZE="13"/>
</node>
<node CREATED="1124560950701" ID="ID_816405856" MODIFIED="1209144731953" TEXT="besar">
<font NAME="SansSerif" SIZE="15"/>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="ID_544909735" MODIFIED="1209144737731" TEXT="besar sekali">
<font NAME="SansSerif" SIZE="20"/>
<node CREATED="1124560950701" MODIFIED="1124560950701" TEXT="OOh">
<font NAME="SansSerif" SIZE="123"/>
</node>
</node>
</node>
<node CREATED="1124560950701" ID="ID_53656715" MODIFIED="1209144772251" TEXT="Jenis font yang digunakan bisa bermacam-macam">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1199607468" MODIFIED="1209144776997" TEXT="Ini">
<font NAME="Times New Roman" SIZE="16"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1568731425" MODIFIED="1209144782796" TEXT="Atau itu">
<font NAME="Verdana" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1961541891" MODIFIED="1209144791218" TEXT="Atau yang itu">
<font NAME="Dialog" SIZE="21"/>
</node>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1193071041" MODIFIED="1209144850133" TEXT="Gaya node bisa dibuat berbeda-beda">
<node CREATED="1124560950701" ID="_Freemind_Link_1979277285" MODIFIED="1209144855040" TEXT="Ranting">
<node CREATED="1124560950701" ID="_Freemind_Link_89124429" MODIFIED="1209144859226" TEXT="Ranting"/>
<node CREATED="1124560950701" ID="_Freemind_Link_173850525" MODIFIED="1209144863081" TEXT="Ranting"/>
</node>
<node CREATED="1124560950701" ID="_Freemind_Link_1001811541" MODIFIED="1209144867427" STYLE="bubble" TEXT="Balon">
<node CREATED="1124560950701" ID="_Freemind_Link_1677737286" MODIFIED="1209144870382" STYLE="bubble" TEXT="Balon"/>
<node CREATED="1124560950701" ID="_Freemind_Link_978246353" MODIFIED="1209144875880" STYLE="bubble" TEXT="Balon"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" ID="ID_483073690" MODIFIED="1209144893635" TEXT="Node bisa dilipat">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_307016912" MODIFIED="1209144900164" TEXT="Lipat">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_953890024" MODIFIED="1209144904120" TEXT="Tersembunyi">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950701" FOLDED="true" ID="_Freemind_Link_1488567837" MODIFIED="1209144910239" TEXT="Pohon">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_346141495" MODIFIED="1209144968032" TEXT="Ek">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1441151502" MODIFIED="1209144978707" TEXT="Waru">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_534141496" MODIFIED="1209144975323" TEXT="Cemara">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950701" ID="ID_641469382" MODIFIED="1209145007859" TEXT="Node bisa mengandung taut yang mengacu ke ...">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006699" CREATED="1124560950701" ID="ID_339939684" MODIFIED="1209145013397" TEXT="Laman web">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" LINK="http://www.google.com/" MODIFIED="1124560950701" TEXT="http://www.google.com/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_1493827529" LINK="www.google.com" MODIFIED="1124560950701" TEXT="www.google.com">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950701" ID="ID_1854484178" MODIFIED="1209145055708" TEXT="Menurut FreeMind, ini bisa dieksekusi :)">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="ID_278779728" MODIFIED="1209145035199" TEXT="Map lokal">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_1541289178" LINK="C:/Program Files/" MODIFIED="1124560950701" TEXT="C:/Program Files/">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950701" ID="ID_2370204" LINK="/home/" MODIFIED="1124560950701" TEXT="/home/">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#006699" CREATED="1124560950701" ID="ID_738829620" MODIFIED="1209145122154" TEXT="Bisa dieksekusi">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950701" ID="ID_372784718" LINK="%SystemRoot%\regedit.exe" MODIFIED="1124560950701" TEXT="%SystemRoot%\regedit.exe">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#006600" CREATED="1124560950701" ID="ID_785322201" MODIFIED="1209145112239" TEXT="Yang bisa dieksekusi terlihat dari ikonnya.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_1493178463" MODIFIED="1209145084870" TEXT="Dokumen apapun di komputer atau jaringan lokal Anda">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="_Freemind_Link_839677176" MODIFIED="1209145146829" TEXT="Node baris banyak">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1423568963" MODIFIED="1209145323754" TEXT="Node baris banyak dapat dilihat sebagai satu atau beberapa paragraf. Bila Anda hendak membangun basis pengetahuan menggunakan FreeMind, penggunaan hal ini tidak dapat dihindari. Alih-alih menggunakan berkas teks polos untuk menampung isi catatan Anda, Anda dapat menggunakan satu node pendek dengan beberapa node baris banyak sebagai anak-anaknya."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1686184172" MODIFIED="1124560950717" TEXT="&quot;Science is facts; just as houses are made of stones, so is science made of facts; but a pile of stones is not a house and a collection of facts is not necessarily science.&quot; --Henri Poincar&#xe9;"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="ID_1903544860" MODIFIED="1209145372504" TEXT="Node baris banyak pendek dengan baris baru">
<node CREATED="1124560950717" ID="_Freemind_Link_1957797574" MODIFIED="1209145401345" TEXT="Baris,&#xa;yang kedua,&#xa;&#xa;lalu masih satu lagi,&#xa;jadi bagaimana menurut Anda?"/>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="ID_1745174972" MODIFIED="1209145414544" TEXT="Tangkai berlabel dapat diemulasi">
<node CREATED="1124560950717" ID="ID_605733199" MODIFIED="1209145421254" TEXT="Pohon">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_731706632" MODIFIED="1209145426111" TEXT="adalah">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_181561435" MODIFIED="1209145428945" TEXT="Ek">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_897111444" MODIFIED="1209145431819" TEXT="adalah">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_454264987" MODIFIED="1209145434683" TEXT="Waru">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_1002513327" MODIFIED="1209145437397" TEXT="adalah">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_22757936" MODIFIED="1209145439951" TEXT="Cemara">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_701778556" MODIFIED="1209145445198" TEXT="Pohon">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_1248255979" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_1769190795" MODIFIED="1209145448172" TEXT="Daun">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#999999" CREATED="1124560950717" ID="ID_1881802723" MODIFIED="1124560950717" TEXT="&lt;&gt;">
<font NAME="Dialog" SIZE="10"/>
<node CREATED="1124560950717" ID="ID_335664905" MODIFIED="1209145450916" TEXT="Batang">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node COLOR="#669900" CREATED="1124560950717" ID="ID_1556015660" MODIFIED="1209145462263" TEXT="Node bisa diberi ikon">
<icon BUILTIN="knotify"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="back"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" ID="_Freemind_Link_318937820" MODIFIED="1209145473319" TEXT="Anda bisa pakai Awan">
<cloud/>
<node CREATED="1124560950717" ID="ID_963712048" MODIFIED="1209145483894" TEXT="Dengan warna pilihan">
<cloud COLOR="#f1ede6"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" ID="_Freemind_Link_1750585847" MODIFIED="1209145498705" TEXT="Anda bisa pakai taut grafis">
<node CREATED="1124560950717" ID="_Freemind_Link_1212380407" MODIFIED="1209145504193" TEXT="Menghubungkan node">
<arrowlink DESTINATION="_Freemind_Link_1249400461" ENDARROW="Default" ENDINCLINATION="41;0;" ID="Arrow_ID_372445471" STARTARROW="None" STARTINCLINATION="41;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1249400461" MODIFIED="1209145509501" TEXT="Ke node lain">
<arrowlink COLOR="#6600ff" DESTINATION="_Freemind_Link_880551392" ENDARROW="Default" ENDINCLINATION="47;0;" ID="Freemind_Arrow_Link_85185909" STARTARROW="None" STARTINCLINATION="47;0;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_880551392" MODIFIED="1209145515299" TEXT="Dengan warna berbeda">
<arrowlink DESTINATION="_Freemind_Link_1789233193" ENDARROW="Default" ENDINCLINATION="82;44;" ID="Freemind_Arrow_Link_1672464612" STARTARROW="None" STARTINCLINATION="82;44;"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1789233193" MODIFIED="1209145526135" TEXT="Dan rute berbeda"/>
</node>
<node COLOR="#407000" CREATED="1124560950717" ID="_Freemind_Link_127668276" MODIFIED="1209145535778" TEXT="Node bisa diposisikan secara bebas">
<node CREATED="1124560950717" ID="_Freemind_Link_894936766" MODIFIED="1209145538052" TEXT="Satu"/>
<node CREATED="1124560950717" ID="_Freemind_Link_1942481455" MODIFIED="1209145541467" TEXT="Lainnya"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1709752669" MODIFIED="1209145567184" POSITION="right" TEXT="Membuat dan menghapus node">
<node CREATED="1124560950717" ID="ID_13596821" MODIFIED="1209145582576" TEXT="Untuk membuat node anak, tekan Insert."/>
<node CREATED="1124560950717" ID="ID_311857085" MODIFIED="1209145615733" TEXT="Untuk membuat node anak selagi mengedit node lainnya, tekan Insert sambil mengedit."/>
<node CREATED="1124560950717" ID="ID_278636018" MODIFIED="1209145637074" TEXT="Untuk membuat node adik, tekan Enter."/>
<node CREATED="1124560950717" ID="ID_1905108426" MODIFIED="1209145650914" TEXT="Untuk membuat node kakak, tekan Shift + Enter."/>
<node CREATED="1124560950717" ID="ID_244320564" MODIFIED="1209145667187" TEXT="Untuk menghapus node, tekan Delete"/>
<node CREATED="1124560950717" ID="ID_1712732486" MODIFIED="1209145684793" TEXT="Untuk menghapus node dan menyimpannya untuk ditempel, tekan Control + X."/>
<node CREATED="1124560950717" ID="ID_669932662" MODIFIED="1209145717900" TEXT="Cara lain, gunakan menu konteks node dengan mengklik-kanan node."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1700974092" MODIFIED="1209146178042" POSITION="right" TEXT="Mengedit teks node">
<node CREATED="1124560950717" ID="_Freemind_Link_519923426" MODIFIED="1209146228715" TEXT="Untuk mengedit node, tekan F2, Home, atau End, atau dari menu konteks node pilih Edit. Untuk menyelesaikan penyuntingan, tekan Enter.">
<arrowlink DESTINATION="_Freemind_Link_519923426" ENDARROW="Default" ENDINCLINATION="0;0;" ID="Freemind_Arrow_Link_1179992477" STARTARROW="None" STARTINCLINATION="0;0;"/>
</node>
<node CREATED="1124560950717" ID="ID_193947887" MODIFIED="1209146247882" TEXT="Untuk mengganti teks dalam node dengan yang baru, mulailah mengetik."/>
<node CREATED="1124560950717" ID="ID_735369454" MODIFIED="1209146277185" TEXT="Untuk memaksakan editor node panjang saat mengedit node pendek, tekan Alt + Enter."/>
<node CREATED="1124560950717" ID="ID_1959309673" MODIFIED="1209146378340" TEXT="Untuk memisahkan sebuah node panjang, gunakan tombol Pisahkan di atas editor node panjang, atau tekan Alt + S di editor node panjang."/>
<node CREATED="1124560950717" ID="ID_1980075999" MODIFIED="1209146432428" TEXT="Untuk memasukkan baris baru dalam editor node panjang, tekan Control + Enter. Anda tidak dapat memasukkan baris baru di dalam editor node pendek.">
<arrowlink DESTINATION="_Freemind_Link_1445647544" ENDARROW="Default" ENDINCLINATION="118;0;" ID="Freemind_Arrow_Link_1628309717" STARTARROW="None" STARTINCLINATION="118;0;"/>
</node>
<node CREATED="1124560950717" ID="ID_280042855" MODIFIED="1209146502509" TEXT="Untuk menyalin pilihan ke papan klip saat mengedit node panjang, tekan tombol tetikus kanan dan pilih Salin."/>
<node CREATED="1124560950717" ID="ID_816706434" MODIFIED="1209146564448" TEXT="Untuk memasukkan simbol khusus seperti &#xa9;, sisipkan simbol lewat editor teks favorit Anda seperti  Microsoft Word, lalu tempelkan ke dalam FreeMind."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1445647544" MODIFIED="1209146708815" TEXT="Bawaannya, Enter mengakhiri penyuntingan node panjang, dan Control + Enter menyisipkan baris baru. Dengan menghapus kotak pilihan &quot;Enter untuk Menerapkan&quot;, Anda dapat membalik fungsi dari kunci-kunci tersebut, sehingga menjadi Enter untuk baris baru dan Control + Enter mengakhiri penyuntingan. Selanjutnya, pilihan yang Anda buat disimpan dalam setiap sesi FreeMind."/>
<node CREATED="1124560950717" ID="ID_403957298" MODIFIED="1209146748833" STYLE="fork" TEXT="FreeMind sepenuhnya mendukung Unicode. Jadi, Anda dapat menggunakan aksara apapun pilihan Anda."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1660149394" MODIFIED="1209146760409" POSITION="right" TEXT="Memformat node">
<node CREATED="1124560950717" ID="ID_16709297" MODIFIED="1209146794338" TEXT="Untuk menebalkan huruf node, tekan Ctrl + B.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_436634279" MODIFIED="1209146788710" TEXT="Untuk memiringkan huruf node, tekan Ctrl + I.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_605709251" MODIFIED="1209146806115" TEXT="Untuk mengganti warna teks node, tekan Alt + C.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1004006951" MODIFIED="1209146860563" TEXT="Untuk menggantui warna latar belakang node, dari menu konteks node pilih Format &gt; Warna Latar Belakang."/>
<node CREATED="1124560950717" ID="ID_1279126013" MODIFIED="1209146902223" TEXT="Untuk memperbesar huruf, tekan Control + plus (bukan plus di kunci numerik).">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_689591166" MODIFIED="1209146930163" TEXT="Untuk memperkecil huruf, tekan Control + minus (bukan minus di kunci numerik).">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1883860478" MODIFIED="1209146952315" TEXT="Untuk mengganti jenis font, gunakan kotak di luntang utama."/>
<node CREATED="1124560950717" ID="ID_934867667" MODIFIED="1209146968589" TEXT="Untuk menyalin format node, tekan Alt + C"/>
<node CREATED="1124560950717" ID="ID_1327202234" MODIFIED="1209146982909" TEXT="Untuk menempelkan format ke node, tekan Alt + V."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_526328879" MODIFIED="1209174502297" POSITION="right" TEXT="Menggunakan gaya fisik">
<node CREATED="1124560950717" ID="ID_163328245" MODIFIED="1209174573249" TEXT="Untuk menerapkan gaya fisik, dari menu konteks node pilih Gaya Fisik &gt; Gaya Pilihan Anda. Untuk mempercepat penerapan gaya fisik, gunakan kunci pintasan seperti terlihat di menu konteks tersebut."/>
<node CREATED="1124560950717" ID="ID_1479089058" MODIFIED="1209174917774" TEXT="Untuk menambahkan gaya fisik Anda sendiri, dengan asumsi Anda punya kemampuan teknis, edit berkas &quot;patterns.xml&quot; berlokasi di map &quot;.freemind&quot; di home directory Anda."/>
<node CREATED="1124560950717" ID="Freemind_Link_1514218661" MODIFIED="1209175093417">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      [Paragraf ini sudah usang.] Berikut catatan tentang berkas patterns.xml. Gaya fisik diterapkan ke node, bila ada tanda &lt;node&gt;. Diterapkan ke tangkai, bila ada tanda &lt;edge&gt;. Tanda &lt;node&gt; bisa berisi tanda lain sebagai anaknya. Pelajari berkas &quot;patterns.xml&quot; yang disediakan dari FreeMind.
    </p>
  </body>
</html></richcontent>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1697687428" MODIFIED="1209175158320" POSITION="right" TEXT="Menandai node dengan awan">
<node CREATED="1124560950717" ID="ID_819249895" MODIFIED="1209175199559" TEXT="Awan sangat cocok untuk menandai area tertentu. Yang ditandai adalah node dan semua keturunannya."/>
<node CREATED="1124560950717" ID="ID_1363990537" MODIFIED="1209175237524" TEXT="Untuk menambahkan awan, tekan Ctrl + Shift + B atau dari menu konteks node, pilih Sisip &gt; Awan."/>
<node CREATED="1124560950717" ID="ID_1293762493" MODIFIED="1209175322426" STYLE="fork" TEXT="Untuk mengganti warna awan, dari menu konteks node, pilih Format &gt; Warna Awan."/>
<node CREATED="1124560950717" ID="ID_1298148690" MODIFIED="1209175360781" TEXT="Awan bisa menggunakan berbagai warna latar seperti hijau ...">
<cloud COLOR="#e1f2e1"/>
<node CREATED="1124560950717" ID="ID_251339755" MODIFIED="1209175372228" TEXT="... atau coklat.">
<cloud COLOR="#ede5d5"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_203858515" MODIFIED="1209175396833" POSITION="right" TEXT="Menambahkan hipertaut">
<node CREATED="1124560950717" ID="ID_951732434" MODIFIED="1209175545367" TEXT="Untuk menambahkan hipertaut ke node, tekan Ctrl + K atau dari menu konteks node, pilih Sisip &gt; Hipertaut."/>
<node CREATED="1124560950717" ID="ID_800098735" MODIFIED="1209175628276" TEXT="Untuk mencopot hipertaut, kosongkan setelan hipertaut setelah menekan Ctrl + K."/>
<node CREATED="1124560950717" ID="ID_292357559" MODIFIED="1209175738865">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Untuk membuat taut ke alamat pos-el, gunakan format <i>mailto:don.bonton@supermail.com</i>.
    </p>
  </body>
</html></richcontent>
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_299108667" MODIFIED="1209175726237">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Untuk membuat taut ke alamat pos-el dengan subjek, gunakan format <i>mailto:don.bonton@supermail.com?subject=Ini judul suratnya</i>.
    </p>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950717" ID="ID_1536348129" MODIFIED="1209175768918" TEXT="Hipertaut dapat mengacu ke laman web, berkas lokal, local files, atau alamat pos-el."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1044397139" MODIFIED="1209175957209" POSITION="right" TEXT="Menambahkan ikon">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_943341306" MODIFIED="1209175971259" TEXT="Node bisa memiliki beberapa ikon."/>
<node CREATED="1124560950717" ID="ID_412021555" MODIFIED="1209176046407" TEXT="Untuk menambahkan ikon ke node, pilih node dan klik satu dari beberapa ikon yang ditampilkan di luntang kedua. Ketika menggerakkan penunjuk tetikus ke luntang kedua, tahan Alt atau Control supaya fokus tidak lepas dari node tersebut."/>
<node CREATED="1124560950717" ID="ID_1191551492" MODIFIED="1209176262718" TEXT="Untuk mencopot satu ikon, tekan tanda silang merah yang terletak paling atas di luntang ikon."/>
<node CREATED="1124560950717" ID="ID_1685973688" MODIFIED="1209176295746" TEXT="Untuk mencopot semua ikon, tekan tanda tempat sampah di bagian atas luntang ikon."/>
<node CREATED="1124560950717" ID="ID_116898291" MODIFIED="1209176327421" TEXT="Untuk menambahkan ikon baru ke node tanpa menggunakan luntang kedua, tekan Alt + I."/>
<node CREATED="1124560950717" ID="ID_998319853" MODIFIED="1209176368470" TEXT="Tidak ada pilihan untuk menggunakan ikon Anda sendiri; Anda dapat memilih dari ikon yang disediakan oleh FreeMind saja."/>
<node CREATED="1124560950717" ID="ID_1861765800" MODIFIED="1209225434093" TEXT="Untuk menampilkan atau menyembunyikan luntang ikon, dari menu konteks di latar belakang pilih Luntang Kedua. Luntang ikon disebut sebagai luntang kedua di sini."/>
<node CREATED="1124560950717" ID="ID_1851690875" MODIFIED="1209225471036" STYLE="fork" TEXT="Ikon yang tersedia adalah seperti yang ditempelkan di node ini..">
<icon BUILTIN="help"/>
<icon BUILTIN="messagebox_warning"/>
<icon BUILTIN="idea"/>
<icon BUILTIN="button_ok"/>
<icon BUILTIN="button_cancel"/>
<icon BUILTIN="back"/>
<icon BUILTIN="forward"/>
<icon BUILTIN="attach"/>
<icon BUILTIN="ksmiletris"/>
<icon BUILTIN="clanbomber"/>
<icon BUILTIN="desktop_new"/>
<icon BUILTIN="flag"/>
<icon BUILTIN="gohome"/>
<icon BUILTIN="kaddressbook"/>
<icon BUILTIN="knotify"/>
<icon BUILTIN="korn"/>
<icon BUILTIN="Mail"/>
<icon BUILTIN="password"/>
<icon BUILTIN="pencil"/>
<icon BUILTIN="stop"/>
<icon BUILTIN="wizard"/>
<icon BUILTIN="xmag"/>
<icon BUILTIN="bell"/>
<icon BUILTIN="bookmark"/>
<icon BUILTIN="penguin"/>
<icon BUILTIN="licq"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="_Freemind_Link_1996597932" MODIFIED="1209225505646" POSITION="right" TEXT="Menambah taut grafis">
<node CREATED="1124560950717" ID="ID_1153966308" MODIFIED="1209225584530" TEXT="Untuk membuat taut grafis antara dua node, seret node dan jatuhkan di atas node lainnya sambil menahan sekaligus tombol Shift dan Control; lepaskan tombol tetikus sebelum melepaskan tombol Shift dan Control.">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="255;0;" ID="Freemind_Arrow_Link_1428344028" STARTARROW="None" STARTINCLINATION="255;0;"/>
</node>
<node CREATED="1124560950717" ID="ID_1650090059" MODIFIED="1209225611809" TEXT="Cara lain, seret dan jatuhkan menggunakan tombol tetikus kanan."/>
<node CREATED="1124560950717" ID="_Freemind_Link_208378337" MODIFIED="1209225642733" TEXT="Untuk mengganti warna taut, gunakan menu konteks taut, dengan mengklik-kanan taut grafis."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1484370636" MODIFIED="1209225695830" TEXT="Untuk mengganti panah taut, gunakan menu konteks taut."/>
<node CREATED="1124560950717" ID="ID_1700277646" MODIFIED="1209225707637" TEXT="Untuk menghapus taut, gunakan menu konteks taut,"/>
<node CREATED="1124560950717" ID="_Freemind_Link_266716332" MODIFIED="1209225733974" TEXT="Untuk bernavigasi ke salah satu node ujung suatu taut, gunakan menu konteks taut."/>
<node CREATED="1124560950717" ID="_Freemind_Link_1015289745" MODIFIED="1209225763717" TEXT="Untuk mengganti rute sebuah taut berpanah, seret dan pindahkan taut tersebut.">
<arrowlink DESTINATION="_Freemind_Link_266716332" ENDARROW="Default" ENDINCLINATION="256;22;" ID="Freemind_Arrow_Link_1273596772" STARTARROW="None" STARTINCLINATION="244;32;"/>
</node>
<node CREATED="1124560950717" ID="ID_1921255250" MODIFIED="1209225773561" TEXT="Berikut contoh tautan grafis."/>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_1451667289" MODIFIED="1209225777237" TEXT="Contoh">
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1170112929" MODIFIED="1209225782684" TEXT="Taut ke bagian lain">
<arrowlink COLOR="#9999ff" DESTINATION="_Freemind_Link_1492563156" ENDARROW="Default" ENDINCLINATION="117;0;" ID="Freemind_Arrow_Link_33407992" STARTARROW="Default" STARTINCLINATION="30;0;"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" FOLDED="true" ID="ID_466382348" MODIFIED="1209225792469" TEXT="Node dengan anak terlipat">
<node CREATED="1124560950717" ID="_Freemind_Link_1492563156" MODIFIED="1209225807130" TEXT="Node anak"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="_Freemind_Link_1370577235" MODIFIED="1209225796815" TEXT="Taut lainnya">
<arrowlink DESTINATION="_Freemind_Link_1170112929" ENDARROW="Default" ENDINCLINATION="61;0;" ID="Freemind_Arrow_Link_1872050149" STARTARROW="None" STARTINCLINATION="61;0;"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_423038022" MODIFIED="1209225822962" POSITION="right" TEXT="Mencari">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1853186827" MODIFIED="1209226056919" STYLE="fork" TEXT="Untuk mencari teks dalam suatu node dan semua node keturunannya, tekan Ctrl + F atau dari menu, pilih Edit &gt; Temukan.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1654127314" MODIFIED="1209226038713" TEXT="Untuk menemukan kecocokan berikutnya dari pencarian sebelumnya, tekan Ctrl + G atau dari menu, pilih Edit &gt; Temukan Berikutnya.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1278869580" MODIFIED="1209226104828" TEXT="Untuk mencari di seluruh peta, posisikan ke node tengah dengan menekan  Escape sebelum mencari."/>
<node CREATED="1124560950717" ID="ID_642414422" MODIFIED="1209226593901" TEXT="Pencarian dilakukan melebar lebih dahulu, baru ke dalam. Ini sesuai dengan pemikiran bahwa makin dalam sebuah node, makin banyak detail yang disampaikan dalam node."/>
<node CREATED="1124560950717" ID="ID_876514246" MODIFIED="1209226615812" TEXT="Ingat bahwa tidak seluruh peta dicari, hanya node dan keturunannya saja."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_653540280" MODIFIED="1209226631074" POSITION="right" TEXT="Memilih banyak node">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_296855940" MODIFIED="1209226650853" TEXT="Untuk memilih banyak node, tahan Shift atau Control sambil mengklik. ">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_35755182" MODIFIED="1209226704931" TEXT="Untuk menambah satu node ke dalam pilihan banyak node, tahan Control ketika mengklik.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1770763567" MODIFIED="1209227478723" STYLE="fork" TEXT="Untuk memilih serentetan node berturutan, tahan Shift ketika mengklik, atau tahan Shift sambil berpindah-pindah menggunakan tombol panah.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_88845581" MODIFIED="1209273334978" TEXT="Untuk memilih satu anak dan semua keturunannya, tahan Alt sambil mengklik, atau tahan Shift sambil berpindah dari suatu node ke induknya."/>
<node CREATED="1124560950717" ID="ID_922127420" MODIFIED="1209273362337" TEXT="Untuk membatalkan pilihan banyak node, klik pada latar belakang peta atau pada node yang tidak terpilih."/>
<node CREATED="1124560950717" ID="ID_1592480083" MODIFIED="1209273421031" TEXT="Untuk memilih semua node yang terlihat, dari menu gunakan Edit &gt; Pilih Semua yang Terlihat."/>
<node CREATED="1124560950717" ID="ID_1593012221" MODIFIED="1209273506554" TEXT="Untuk memilih semua node yang terlihat dari suatu cabang, dari menu gunakan Edit &gt; Pilih Cabang yang Terlihat."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_1024903226" MODIFIED="1209273548565" POSITION="right" TEXT="Seret dan jatuhkan">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1178943684" MODIFIED="1209273566891" TEXT="Anda dapat memindah-mindahkan node dengan menyeret dan menjatuhkannya.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_215653657" MODIFIED="1209273607279" TEXT="Untuk menjatuhkan node sebagai anak, posisikan penunjuk di bagian luar node tujuan ketika menjatuhkan.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_343240384" MODIFIED="1209273638865" TEXT="Untuk menjatuhkan node sebagai saudara, posisikan penunjuk di bagian atas node tujuan ketika menjatuhkan.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="_Freemind_Link_1994214827" MODIFIED="1209273677360" TEXT="Untuk menyalin node alih-alih memindahkan, tahan Control saat menyeret, atau seret memakai tombol tetikus tengah.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_942351938" MODIFIED="1209273829298" TEXT="Untuk mengedit peta yang sudah ada, seret berkasnya dan jatuhkan di latar belakang FreeMind. Hal ini bekerja minimal di sistem operasi Microsoft Windows."/>
<node CREATED="1124560950717" ID="ID_1876033674" MODIFIED="1209273855256" TEXT="Untuk membuat taut grafis, seret dan jatuhkan node menggunakan tombol tetikus kanan."/>
<node CREATED="1124560950717" ID="ID_1278420396" MODIFIED="1209273877077" TEXT="Bila Anda memilih banyak node, maka semuanya akan dipindahkan atau disalin.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_965930833" MODIFIED="1209273918076" TEXT="Anda dapat menjatuhkan data dari aplikasi eksternal, seperti berkas dalam sistem operasi Microsoft Windows, atau teks terpilih dari Microsoft Internet Explorer."/>
</node>
<node COLOR="#407000" CREATED="1124560950717" FOLDED="true" ID="Freemind_Link_958781924" MODIFIED="1209274000895" POSITION="right" TEXT="Menyalin dan menempel">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_1561854528" MODIFIED="1209274053671" TEXT="Anda dapat menyalin dan menempel (banyak) node antar MindMap seperti biasa. Selain itu, Anda dapat menempelkan teks biasa atau HTML dari aplikasi lain.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_65809205" MODIFIED="1209274132074" TEXT="Bila menempelkan teks polos, banyak baris akan ditempelkan sebagai banyak node, dan posisi kedalamannya ditentukan oleh banyaknya spasi di awal teks. Berikut contohnya."/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1627092027" MODIFIED="1209274187534" TEXT="Pohon&#xa;     Ek&#xa;     Cemara">
<node CREATED="1124560950717" ID="ID_55526373" MODIFIED="1209274156138" TEXT="ditempelkan sebagai">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_787112439" MODIFIED="1209274159944" TEXT="Pohon">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1397202134" MODIFIED="1209274162718" TEXT="Ek">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_475104996" MODIFIED="1209274165892" TEXT="Cemara">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_838592934" MODIFIED="1209274297221" TEXT="Teks HTML akan ditempelkan sebagai teks polos. Di samping itu, tautan yang tercantum dalam HTML akan ditempelkan sebagai anak dari sebuat node tambahan dengan nama &quot;Links&quot;. Berikut contohnya."/>
<node CREATED="1124560950717" ID="ID_498865809" MODIFIED="1209274303911" TEXT="Contoh hasil penempelan">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_785656568" MODIFIED="1209274321686" STYLE="fork" TEXT="Belanja (120236)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_785399167" MODIFIED="1209274335066" TEXT="Gaya Hidup (19)">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1914167530" MODIFIED="1124560950717" TEXT="Links">
<font BOLD="true" NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_647961468" LINK="http://directory.google.com/Top/Shopping/" MODIFIED="1209274342707" TEXT="Belanja">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950717" ID="ID_1021552074" LINK="http://directory.google.com/Top/Home/Urban_Living/" MODIFIED="1209274348295" TEXT="Gaya Hidup">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node CREATED="1124560950717" ID="ID_1204515717" MODIFIED="1209274426878" TEXT="Bila Anda menempelkan senarai berkas dari Explorer di Microsoft Windows, taut ke berkas-berkas tersebut akan ditempelkan."/>
<node CREATED="1124560950717" ID="ID_673825377" MODIFIED="1209275981453" STYLE="fork" TEXT="Bila Anda menyalin suatu cabang dan menempelkannya ke dalam editor teks polos, struktur pohon akan ditunjukkan dengan indentasi. Hipertaut ditempelkan dalam tanda kurung &lt; &gt;. Berikut contohnya."/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1447539819" MODIFIED="1209275989294" TEXT="Pohon">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_1516542995" MODIFIED="1209275992168" TEXT="Ek">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950717" ID="ID_133833504" MODIFIED="1209275995003" TEXT="Cemara">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950717" ID="ID_268647755" MODIFIED="1209276004807" TEXT="ditempelkan sebagai">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_1462977187" MODIFIED="1209276023614" STYLE="fork" TEXT="Pohon&#xa;     Ek&#xa;     Cemara&#xa;     Google &lt;http://www.google.com/&gt;&#xa;">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_1281956134" LINK="http://www.google.com/" MODIFIED="1124560950732" TEXT="Google">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="ID_1354652421" MODIFIED="1209276139520" STYLE="fork" TEXT="Bila dari FreeMind Anda menyalin suatu cabang dan menempelkannya ke dalam editor yang mendukung format teks kaya (rich text format - RTF), pemformatan seperti warna dan font ikut ditempelkan juga. Hipertaut ditempelkan dalam tanda kurung &lt; &gt;, seperti pada teks polos. Editor yang mendukung teks kaya termasuk Microsoft Word, Wordpad atau Microsoft Outlook, atau beberapa editor catatan di Linux."/>
<node CREATED="1124560950732" ID="ID_866129685" MODIFIED="1209276823784" TEXT="Untuk menyalin node tanpa keturunannya, tekan Ctrl + Shift + C atau dari menu konteks node, pilih Salin Tunggal."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="_Freemind_Link_1540212684" MODIFIED="1209276831606" POSITION="right" TEXT="Berpindah-pindah">
<node CREATED="1124560950732" ID="ID_553732792" MODIFIED="1209276874027" TEXT="Untuk menggerakan penunjuk ke atas, bawah, kri atau kanan, gunakan tombol panah."/>
<node CREATED="1124560950732" ID="ID_1130754383" MODIFIED="1209277294121" TEXT="Untuk berpindah ke puncak cabang suatu pohon, tekan PageUp."/>
<node CREATED="1124560950732" ID="ID_1966957004" MODIFIED="1209277312187" TEXT="Untuk berpindah ke ujung bawah suatu pohon, tekan PageDown."/>
<node CREATED="1124560950732" ID="ID_1257350203" MODIFIED="1209277327238" TEXT="Untuk berpindah ke node akar, tekan Escape."/>
<node CREATED="1124560950732" ID="_Freemind_Link_97763226" MODIFIED="1209277557089" TEXT="Untuk memposisikan node secara bebas, seret pegangan yang tidak terlihat di sisi node ke arah node akar, dan pindahkan."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_4727471" MODIFIED="1209277604066" POSITION="right" TEXT="Membuka-tutup lipatan">
<node CREATED="1124560950732" ID="ID_1044015528" MODIFIED="1209277633639" TEXT="Untuk melipat node, tekan Space, atau dari menu konteks node, pilih Buka/Tutup Lipatan."/>
<node CREATED="1124560950732" ID="ID_1520325492" MODIFIED="1209277684542" TEXT="Untuk membuka lipatan, tekan Space, atau dari menu konteks node, pilih Buka/Tutup Lipatan, atau tekan tombol panah ke arah pembukaan lipatan."/>
<node CREATED="1124560950732" ID="ID_871275537" MODIFIED="1209277858893" TEXT="Untuk membuka-tutup lipatan secara bertingkat, tahan Alt sambil menggunakan roda tetikus, atau tekan Alt + PageUp atau Alt + PageDown. Pada peta ukuran besar, gunakan fungsi ini dengan hati-hati, karena dapat menyebabkan masalah memori."/>
<node CREATED="1124560950732" ID="ID_245769138" MODIFIED="1209277930345" TEXT="Untuk membuka semua lipatan, gunakan tombol tanda plus abu-abu di luntang utama, atau dari menu pilih Navigasi &gt; Buka Semua."/>
<node CREATED="1124560950732" ID="ID_91039853" MODIFIED="1209277985695" TEXT="Untuk melipat semua, tekan tombol tanda minus abu-abu di luntang utama, atau dari menu pilih Navigasi &gt; Lipat Semua."/>
<node CREATED="1124560950732" ID="ID_162455080" MODIFIED="1209278021336" TEXT="Node terlipat ditandai dengan lingkaran kecil yang menempel ke arah luar."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_516331171" MODIFIED="1209278047444" POSITION="right" TEXT="Berpindah ke peta lain">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_396490844" MODIFIED="1209278081583" TEXT="Untuk berpindah ke peta lain yang sudah dibuka, klik kanan di latar belakang dan pilih peta lain tersebut dari menu konteks.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_467411537" MODIFIED="1209278088763" POSITION="right" TEXT="Menggulung peta">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_517576721" MODIFIED="1209278135130" TEXT="Untuk menggulung peta, seret latar belakang dan pindah-pindahkan, atau gunakan roda tetikus. Untuk menggulung secara mendatar dengan roda tetikus, tahan Shift atau salah satu tombol tetikus.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913137192" MODIFIED="1209278154197" POSITION="right" TEXT="Melakukan zum">
<node CREATED="1124560950732" ID="ID_1845799508" MODIFIED="1209278210508" TEXT="Untuk zum, gunakan roda tetikus sambil menahan tombol Control, atau tekan tombol Alt + Up atau Down. Cara lain, gunakan kolom zum di luntang utama."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1318678369" MODIFIED="1209278220012" POSITION="right" TEXT="Urungkan">
<node CREATED="1124560950732" ID="ID_447059498" MODIFIED="1209278246220" TEXT="Untuk mengurungkan, tekan Control + Z, atau dari menu, pilih Edit &gt; Urungkan."/>
<node CREATED="1124560950732" ID="ID_496703552" MODIFIED="1209278269393" TEXT="Untuk mengulang, tekan Control + Y, atau dari menu, pilih Edit &gt; Ulangi."/>
<node CREATED="1124560950732" ID="ID_983204383" MODIFIED="1209278313516" TEXT="Untuk menyetel jumlah langkah yang dicatat untuk bisa diurungkan, dari menu pilih Alat &gt; Preferensi."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_22510332" MODIFIED="1209278324883" POSITION="right" TEXT="Ekspor ke HTML">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_979412403" MODIFIED="1209283147141" TEXT="Untuk mengekspor cabang ke HTML, tekan Control + H. Halaman hasil ekspor HTML dapat mendukung pelipatan, tergantung dari setelan preferensi."/>
<node CREATED="1124560950732" ID="ID_655995359" MODIFIED="1209283183713" TEXT="Fungsi ekspor yang lain bisa diaktifkan dari menu, pilih Ekspor &gt; Sebagai XHTML (versi Javascript)."/>
<node CREATED="1124560950732" ID="ID_1772530062" MODIFIED="1209283265471" TEXT="Untuk mengekspor peta dengan gambar pratinjau dalam format HTML, dari menu pilih Ekspor &gt; Sebagai XHTML (versi gambar peta yang dapat diklik)."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1908686168" MODIFIED="1209283287583" POSITION="right" TEXT="Ekspor ke gambar bitmap atau vektor">
<node CREATED="1124560950732" ID="ID_1425718492" MODIFIED="1209283319959" TEXT="Untuk mengekspor peta sebaga citra PNG, dari menu pilih Berkas &gt; Ekspor &gt; Sebagai PNG."/>
<node CREATED="1124560950732" ID="ID_1060323115" MODIFIED="1209283347339" TEXT="Untuk mengekspor peta sebagai citra JPEG, dari menu pilih Berkas &gt; Ekspor &gt; Sebagai JPEG."/>
<node CREATED="1124560950732" ID="ID_443611240" MODIFIED="1209283422497" TEXT="Untuk mengekspor peta sebagai SVG, dari menu piih Berkas &gt; Ekspor &gt; Sebagai SVG. Fungsi ini hanya tersedia bila tancapan (plug-in)  SVG telah  terpasang."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_329770204" MODIFIED="1209283434003" POSITION="right" TEXT="Ekspor ke format XML lainnya">
<node CREATED="1124560950732" ID="ID_209299544" MODIFIED="1209283534357" TEXT="Untuk mengekspor peta ke format XML lainnya menggunakan lembar transformasi XSLT (XSLT transformation sheet), dari menu pilih Berkas &gt; Ekspor &gt; Dengan XSLT."/>
<node CREATED="1124560950732" ID="ID_897570861" MODIFIED="1209283591640" TEXT="Untuk mengekspor peta ke dokumen OpenOffice.org 1.4 Writer, dari menu pilih Berkas &gt; Ekspor &gt; Sebagai dokumen OpenOffice.org Writer."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1841136119" MODIFIED="1209283607262" POSITION="right" TEXT="Mengimpor struktur map">
<font NAME="Dialog" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_1862161571" MODIFIED="1209283832536" TEXT="Untuk mengimpor struktur berkas, dari menu pilih Berkas &gt; Impor &gt; Struktur Map. Anda akan ditanya tentang map yang strukturnya hendak diimpor. Yang dimaksud struktur adalah pohon dari semua submap (baik langsung maupun tidak) dengan tautan ke berkas-berkas dalam submap tersebut. Contoh dari struktur yang diimpor sebagai berikut."/>
<node COLOR="#996600" CREATED="1124560950732" FOLDED="true" ID="ID_1276543096" MODIFIED="1209283619300" TEXT="Contoh">
<font NAME="SansSerif" SIZE="12"/>
<node COLOR="#996600" CREATED="1124560950732" ID="ID_1028597241" MODIFIED="1209283613201" TEXT="Map terpilih">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" LINK="C:\Program Files\Microsoft Office\Office\Bitmaps" MODIFIED="1124560950732" TEXT="C:\Program Files\Microsoft Office\Office\Bitmaps">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node CREATED="1124560950732" ID="ID_697101222" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/" MODIFIED="1124560950732" TEXT="Dbwiz">
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/ASSETS.GIF" MODIFIED="1124560950732" TEXT="ASSETS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/CONTACTS.GIF" MODIFIED="1124560950732" TEXT="CONTACTS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/EVTMGMT.GIF" MODIFIED="1124560950732" TEXT="EVTMGMT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/EXPENSES.GIF" MODIFIED="1124560950732" TEXT="EXPENSES.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/INVENTRY.GIF" MODIFIED="1124560950732" TEXT="INVENTRY.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/LEDGER.GIF" MODIFIED="1124560950732" TEXT="LEDGER.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/ORDPROC.GIF" MODIFIED="1124560950732" TEXT="ORDPROC.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/RESOURCE.GIF" MODIFIED="1124560950732" TEXT="RESOURCE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/SERVICE.GIF" MODIFIED="1124560950732" TEXT="SERVICE.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Dbwiz/TIMEBILL.GIF" MODIFIED="1124560950732" TEXT="TIMEBILL.GIF"/>
</node>
<node CREATED="1124560950732" ID="ID_923094028" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/" MODIFIED="1124560950732" TEXT="Styles">
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF" MODIFIED="1124560950732" TEXT="ACBLENDS.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF" MODIFIED="1124560950732" TEXT="ACBLUPRT.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF" MODIFIED="1124560950732" TEXT="ACEXPDTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF" MODIFIED="1124560950732" TEXT="ACINDSTR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF" MODIFIED="1124560950732" TEXT="ACRICEPR.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF" MODIFIED="1124560950732" TEXT="ACSNDSTN.GIF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF" MODIFIED="1124560950732" TEXT="ACSUMIPT.GIF"/>
<node CREATED="1124560950732" ID="ID_691308381" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_269203785" MODIFIED="1209284117917" POSITION="right" TEXT="Mengimpor Favorit Internet Explorer">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="Freemind_Link_260446736" MODIFIED="1209284330122">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <p>
      Untuk mengimpor favorit dari Internet Explorer ke dalam FreeMind,dari menu pilih Berkas &gt; Impor &gt; Favorit dari Explorer. Anda akan diminta memasukkan jalur ke map tempat favorit disimpan. Nama map tersebut adalah Favorit (atau Favorites) dan Anda dapat mencarinya di sistem Anda. Di Windows XP dengan antarmuka bahasa Indonesia, jalurnya adalah C:\Documents and Settings\&lt;nama pemakai&gt;\Favorit.
    </p>
  </body>
</html>
</richcontent>
</node>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_1939528579" MODIFIED="1209284341398" TEXT="Kata kunci: Microsoft Internet Explorer, MSIE, MS IE.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1709974530" MODIFIED="1209284361837" POSITION="right" TEXT="Mengimpor MindMap dari MindManager X5">
<node CREATED="1124560950732" ID="ID_1824289094" MODIFIED="1209284400102" TEXT="Untuk mengimpor MindMap dari MindManager X5, dari menu, pilih Berkas &gt; Impor &gt; Peta MindManager X5."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_913645795" MODIFIED="1209284422485" POSITION="right" TEXT="Integrasi dengan Word atau Outlook">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_239999971" MODIFIED="1209284474209" TEXT="Anda dapat menempelkan peta atau cabang ke dalam Microsoft Word, Wordpad, atau pesan Outlook. Pada umumnya, Anda dapat menempel ke aplikasi apapun yang mendukung teks kaya. Pemformatan teks dan tautan akan ikut ditempelkan.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1941398988" LINK="mailto:don.bonton@supermail.com" MODIFIED="1209284522989" TEXT="Klik pada taut surat (mailto:don.bonton@supermail.com) akan membuka Outlook untuk membuat pesan baru, bila tidak disetel lain di  Windows.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_273515249" LINK="mailto:don.bonton@supermail.com?subject=Ini subjeknya" MODIFIED="1209284611046" TEXT="Anda dapat menggunakan Subjek di tautan surat."/>
<node CREATED="1124560950732" ID="ID_546445267" MODIFIED="1209284658063" TEXT="Cara lain untuk menempelkan MindMap ke Microsoft Word adalah dengan mengekspornya ke HTML berdasarkan tajuk, menyalin HTML-nya dan menempelkannya ke Word."/>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1822195277" MODIFIED="1209284665834" POSITION="right" TEXT="Menyetel preferensi">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_748595231" MODIFIED="1209284705802" TEXT="Untuk mengedit preferensi, dari menu, pilih Alat &gt; Preferensi. Kebanyakan perubahan akan diterapkan hanya setelah FreeMind dimulai ulang."/>
<node CREATED="1124560950732" ID="ID_571002233" MODIFIED="1209284752729" TEXT="Preferensi mencakup pemetaan papan ketik, tingkah laku ekspor HTML, cara memilih node dengan tetikus, pilihan antialias, dan lain-lain."/>
<node COLOR="#999999" CREATED="1124560950732" ID="ID_598925427" MODIFIED="1209284763535" TEXT="Kata kunci: penyesuaian.">
<font NAME="Dialog" SIZE="10"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_1528828442" MODIFIED="1209284775042" POSITION="right" TEXT="Pencetakan">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_70287433" MODIFIED="1209285126817" TEXT="Anda dapat mencetak baik dengan menyesuaikan seluruh peta ke satu halaman, atau dengan mencetak peta ke beberapa lembar kertas. Pilihan ini dapat disetel dari menu Berkas &gt; Penataan Halaman."/>
<node CREATED="1124560950732" ID="ID_756004595" MODIFIED="1209284879542" TEXT="Untuk pemakaian ruang yang lebih baik, gunakan Lanskap dari Penataan Halaman.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_122221947" MODIFIED="1209285103974" TEXT="Belum ada cara mudah untuk membuat pratinjau dari peta Anda sebelum mencetak. Bila Anda memiliki pencetak PostScript atau pengandar (driver) PostScript generik, Anda dapat mencetak peta ke dalam sebuah berkas dan menampilkan berkasnya menggunakan Ghostview atau program serupa. Bila Anda mencoba mencetak peta dengan pencetak yang tidak mengerti PostScript, berkas yang dihasilkan tidak akan menjadi PostScript tapi mungkin PCL, yang tidak bermanfaat bagi Anda."/>
<node CREATED="1124560950732" ID="ID_1665441334" MODIFIED="1209285283413" TEXT="Anda juga dapat mencetak dari perambah (browser) Anda setelah mengekspor peta ke HTML, atau dari Word atau Wordpad setelah menyalin dan menempelkan peta ke dalamnya. Anda juga dapat mengekspor peta ke dalam HTML dengan tajuk, salin dan tempel ke Microsoft Word dan cetak dari situ. Dengan begitu, Anda dapat mengubah-ubah gayanya sesuai keinginan.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_841140408" MODIFIED="1209286969016" POSITION="right" TEXT="Menggunakan teks kaya melalui HTML dalam node">
<node CREATED="1124560950732" ID="ID_1000519218" MODIFIED="1209285355456" TEXT="Node yang dimulai dengan &lt;html&gt; dilukis menggunakan HTML yang terkandung di dalamnya. Fitur ini bermanfaat bagi pemakai dengan pengetahuan teknis. Contohnya sebagai berikut."/>
<node CREATED="1124560950732" ID="ID_854898297" MODIFIED="1209285514234">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <h3>
      Contoh HTML
    </h3>
    <p class="msonormal">
      Ada beberapa lema:
    </p>
    <ul type="disc">
      <li class="msonormal">
        Lema satu
      </li>
      <li class="msonormal">
        Lema dua
      </li>
    </ul>
    <p class="msonormal">
      Anda bisa menggunakan <b>cetak tebal</b> or <i>miring</i>. <u>Garis bawah</u> dan juga <strike>coret</strike>.
    </p>
    <p class="msonormal">
      
    </p>
    <p class="msonormal">
      Anda bisa buat tabel:
    </p>
    <table class="msonormaltable" cellpadding="0" border="1" style="border: none" cellspacing="0">
      <tr>
        <td style="border: solid windowtext 1.0pt; padding-top: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-left: .75pt">
          <p class="msonormal">
            Sel1
          </p>
        </td>
        <td style="border-left: none; border: solid windowtext 1.0pt; padding-top: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-left: .75pt">
          <p class="msonormal">
            Sel2
          </p>
        </td>
      </tr>
      <tr>
        <td style="border: solid windowtext 1.0pt; border-top: none; padding-top: .75pt; padding-right: .75pt; padding-bottom: .75pt; padding-left: .75pt">
          <p class="msonormal">
            Sel3
          </p>
        </td>
        <td style="border-left: none; border-top: none; padding-top: .75pt; padding-right: .75pt; border-bottom: solid windowtext 1.0pt; border-right: solid windowtext 1.0pt; padding-bottom: .75pt; padding-left: .75pt">
          <p class="msonormal">
            Sel4.
          </p>
        </td>
      </tr>
    </table>
    <p class="msonormal">
      
    </p>
    <p class="msonormal">
      Anda bisa menggunakan berbagai <font color="#999900">warna latar depan.</font>
    </p>
  </body>
</html>
</richcontent>
</node>
<node CREATED="1124560950732" ID="ID_919917120" MODIFIED="1209285575412" TEXT="Node HTML dan gambar tidak didukung ketika mengekspor teks atau RTP (Word, Wordpad). Minimal, penggunaan HTML adalah cara yang mudah untuk publikasi di Web menggunakan applet FreeMind.">
<font NAME="SansSerif" SIZE="12"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="Freemind_Link_271176250" MODIFIED="1209286979321" POSITION="right" TEXT="Menggunakan gambar dalam node">
<font NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_187126341" MODIFIED="1209287077452" TEXT="Untuk menyisipkan gambar ke dalam FreeMind, tekan Alt + K, atau dari menu konteks node, pilih Sisip &gt; Gambar. Dengan menyisipkan gambar, Anda akan kehiangan semua teks yang sebelumnya ada dalam node tersebut. Gambar yang dimasukkan dengan cara ini tidak akan ditempelkan secara benar di luar FreeMind dan mungkin tidak akan terekspor secara benar ke HTML. Gambar dalam FreeMind masih merupakan fitur tahap awal."/>
<node CREATED="1124560950732" ID="ID_1340853323" MODIFIED="1209287107225" STYLE="fork" TEXT="Format gambar yang didukung adalah PNG, JPEG dan GIF."/>
<node CREATED="1124560950732" ID="ID_987713301" MODIFIED="1209287766393" TEXT="Untuk mengubah tautan ke gambar menjadi gambar yang tertampilkan, tekan Alt + K. Anda dapat menyeret dan menjatuhkan beberapa berkas gambar ke dalam FreeMind, memilih beberapa node sekaligus, lalu mengubah semuanya menjadi gambar dengan menekan Alt + K."/>
<node COLOR="#000000" CREATED="1124560950732" ID="ID_238102754" MODIFIED="1209287838507" TEXT="Cara yang lebih teknis dan sedikit lebih sukar untuk menyisipkan gambar adalah sebagai berikut. Anda dapat memasukkan HTML dalam node. Anda perlu memulai isi node dengan tanda &lt;html&gt;. Dengan cara ini, Anda bisa memasukkan gambar ke dalam node.">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_412481192" MODIFIED="1209287848180" TEXT="Sebagai contoh&#xa;  &lt;html&gt;&lt;img src=&quot;linked/Apple.png&quot;&gt;&#xa;  &lt;html&gt;&lt;img src=&quot;file://C:/Users/My Documents/Mind Maps/Linked/Apple.png&quot;&gt;&#xa;">
<font NAME="SansSerif" SIZE="12"/>
</node>
<node CREATED="1124560950732" ID="ID_1072263410" MODIFIED="1209287867909" TEXT="Anda dapat menggunakan taut relatif untuk gambar.">
<edge WIDTH="thin"/>
<font NAME="SansSerif" SIZE="12"/>
</node>
<node COLOR="#996600" CREATED="1124560950732" ID="Freemind_Link_1825247742" MODIFIED="1209287950708" TEXT="Contoh gambar, berhasil dengan baik di beberapa distribusi Windows">
<font BOLD="true" NAME="SansSerif" SIZE="12"/>
<node CREATED="1124560950732" ID="ID_325280427" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLENDS.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACBLUPRT.GIF"/>
  </body>
</html></richcontent>
</node>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACEXPDTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACINDSTR.GIF"/>
  </body>
</html></richcontent>
</node>
</node>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACRICEPR.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" ID="ID_1587596019" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSNDSTN.GIF"/>
  </body>
</html></richcontent>
<node CREATED="1124560950732" MODIFIED="1124560950732">
<richcontent TYPE="NODE"><html>
  <head>
    
  </head>
  <body>
    <img src="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/ACSUMIPT.GIF"/>
  </body>
</html></richcontent>
</node>
</node>
</node>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/GLOBE.WMF" MODIFIED="1124560950732" TEXT="GLOBE.WMF"/>
<node CREATED="1124560950732" LINK="file:/C:/Program Files/Microsoft Office/Office/Bitmaps/Styles/STONE.BMP" MODIFIED="1124560950732" TEXT="STONE.BMP"/>
</node>
</node>
<node COLOR="#407000" CREATED="1124560950732" FOLDED="true" ID="ID_389666008" MODIFIED="1209287968654" POSITION="right" TEXT="Menggunakan penguncian berkas eksperimental">
<node CREATED="1124560950732" ID="ID_783273897" MODIFIED="1209289277205" TEXT="Versi FreeMind saa ini memiliki penguncian berkas eksperimental, yang secara bawaan dinonaktifkan. Implementasi saat ini tidak mencegah konflik penyuntingan (race condition) secara sempurna, tapi mestinya cukup untuk kebanyakan kegunaan praktis. "/>
<node CREATED="1124560950732" ID="ID_540318221" MODIFIED="1209288452680" TEXT="Penguncian berkas memastikan tidak ada lebih dari satu pemakai yang mengedit suatu peta pada saat yang sama, sehingga mencegah agar mereka tidak saling menimpa informasi tanpa sengaja."/>
<node CREATED="1124560950732" ID="ID_1073463144" MODIFIED="1209288477115" TEXT="Untuk mengaktifkan penguncian berkas eksperimental, dari menu, pilih Alat &gt; Preferensi."/>
</node>
</node>
</map>
